//裁剪 限制字数
var cut = function(str,len){
	if(str.length>len){
		str = str.substring(0,len)+"..."
	}
	return str
}
//内容id
var contentid = $.cookie("contentid").substring(1)
//栏目id
var channelid 

//查找内容
$.ajax({
	url:"SearchContentById",
	type:"get",
	data:{
		id:contentid,
	},
	async:false,
	success:function(value)
	{
		var obj = value.data[0]
		$(".hbu_content h2 span").text(cut(obj.title,8))
		$(".hbu_content .content h3").text(obj.title)
		$(".hbu_content .content .time").text(obj.createtime.substring(0,10))
		$(".hbu_content .content .author").text(obj.author)
		//呈现富文本编辑器的内容
		$(".hbu_content .content .info").html(obj.content)
		channelid = obj.channelid
	}
})
//查找栏目
$.ajax({
	url:"SeachChannelById",
	data:{
		channelid,
	},
	success:function(value)
	{
		$(".hbu_content h2 .tolist").text(value.data[0].channelname) //更新栏目名称到页面
		$(".hbu_content h2 .tolist").attr("href","#"+value.data[0].id)
	}
})
//跳转到列表页
$(".tolist").click(function(){
	//存cookie,携带href属性值
	$.cookie("channelid",$(this).attr("href"))
	//页面跳转
	location.href="hbu_list.html"
})