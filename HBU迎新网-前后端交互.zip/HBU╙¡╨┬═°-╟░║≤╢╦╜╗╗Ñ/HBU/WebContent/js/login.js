//alert(1)
$(".btn").click(function(){
	var account = $(".account").val().trim()
	var password = $(".password").val().trim()
	// 发起请求 访问数据库
	$.ajax({
		url:"LoginServlet?account="+account+"&password="+password,//在url中也可以直接传参
		type:"get",
		success:function(value){
			alert(value)
			if(value="登录成功"){
				location.href="main.html"
			}
		}
	
	})
})