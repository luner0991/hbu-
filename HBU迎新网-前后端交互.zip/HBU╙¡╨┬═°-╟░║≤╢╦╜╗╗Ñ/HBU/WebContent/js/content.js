// 获取数据库的的信息
var page = 1
var pageSize = 5 //每页有多少个事件

var loadData = function(){
	var channelid = $(".channelid").val() 
	 var title = $(".title").val().trim()
	 var author = $(".author").val().trim()
	    $.ajax({
	        url:"SearchContent",
	        type:"get",
	        data:{
	            channelid,
	            title,
	            author,
	            page,
	            pageSize
	        },
	        success:function(value){
	            var arr = value.data // 放到tbody表格
	            $("tbody").empty()
	            for(var i=0;i<arr.length;i++){
	                $("tbody").append('<tr>'+
	                        '<td><input type="checkbox"></td>'+
	                        '<td>'+arr[i].id+'</td>'+
	                        '<td>'+arr[i].channelname+'</td>'+
	                        '<td>'+arr[i].title+'</td>'+
	                        '<td>'+arr[i].desc+'</td>'+
	                        '<td>'+arr[i].createtime.substring(0,10)+'</td>'+
	                        '<td>'+arr[i].author+'</td>'+
	                        '<td><img src="upload/'+arr[i].imgurl+'" style="width:120px;height:90px;object-fit:cover" alt=""></td>'+
	                       ' <td>'+
	                          ' <input type="button" value="修改" class="update" index="'+arr[i].id+'">'+
	                         ' <input type="button" value="删除" class="delete">'+
	                        '</td>'+

	                    '</tr>')
	            }
	        },
	        error:function(){
	            alert("查询出错啦")
	        }
	    })
 }


//查找栏目
var loadChannel = function(){
	 $.ajax({
		 url:"SearchChannel",
		 type:"get",
		 success:function(value){
			// console.log(value)
			 var arr = value.data
			 $(".channelid").empty()
			 $(".channelid").append('<option value="">全部</option>')
			 for(var i=0;i<arr.length;i++){
				 //在容器中追加新的channelid
				 $(".channelid").append('<option value="'+arr[i].id+'">'+arr[i].channelname+'</option>')
			 }
				
		 }
	 })
}


//加载分页页码 
var loadPage = function(){
	var channelid = $(".channelid").val() 
	 var title = $(".title").val().trim()
	 var author = $(".author").val().trim()
	    $.ajax({
	    	url:"SearchContentNum",
	    	type:"get",
	    	data:{
	            channelid,
	            title,
	            author,
	        },
	        success:function(value){
	        	// value.count为查询的事件条数
	        	var pageNum = Math.ceil(value.count/pageSize)
	        	$(".page").empty()
	        	$(".page").append("<li class='first'>首页</li>")
	        	$(".page").append("<li class='prev'>上一页</li>")
	        	
	        	for(var i=0;i<pageNum;i++){
	        		if(i==0){
	        			$(".page").append("<li class='current item'>"+(i+1)+"</li>")
	        		}else{
	        			$(".page").append("<li class ='item'>"+(i+1)+"</li>")
	        		}
	        		
	        	}
	        	$(".page").append("<li class='next'>下一页</li>")
	        	$(".page").append("<li class='last'>尾页</li>")
	        	
	        	
	        },
	        error:function(){
	            alert("分页页码加载出错啦")
	        }
	    })
	
}

// 进入页面查找
 loadData()
// 进入页面加载页码
 loadPage()
 //进入页面加载栏目
 loadChannel()
 
 
 
 
//点击按钮查找
$(".search").on("click",function(){
    // alert(1)
	page=1
	 loadData()
	 loadPage()
    
})


//任意页切换
$(".page").on("click",".item",function(){
	//数据切换
	page = $(this).text() // 获取当前点击页码的值
	loadData() //重新加载页面
	
	//样式切换
	$(this).siblings().removeClass("current")
	$(this).addClass("current")
	
})
 
//首页切换
$(".page").on("click",".first",function(){
	//数据切换
	page =1
	loadData()
	//样式切换
	$(".item").removeClass("current")
	$(".item").first().addClass("current")
})
 

//尾页切换
$(".page").on("click",".last",function(){
	//数据切换
	page = $(".item").length
	loadData()
	//样式切换
	$(".item").removeClass("current")
	$(".item").last().addClass("current")
})

//上一页切换
$(".page").on("click",".prev",function(){
	if(page==1){
		alert("已经是第一页啦")
		return
	}
	//数据切换
	page--
	loadData()
	//样式切换
	$(".item").removeClass("current")
	$(".item").eq(page-1).addClass("current")
})

//下一页切换
$(".page").on("click",".next",function(){
	if(page==$(".item").length){
		alert("已经是最后一页啦")
		return
	}
	//数据切换
	page++
	loadData()
	//样式切换
	$(".item").removeClass("current")
	$(".item").eq(page-1).addClass("current")
})





// 点击添加跳转到添加页面
$(".add").click(function(){
	//页面跳转
	location.href="add.html"
})

// 点击跳转到修改页面 给后来生成的元素绑事件，需要使用事件委托
$("tbody").on("click",".update",function(){
	//设置cookie
	$.cookie("id",$(this).attr("index"))
	location.href="update.html"
})











 