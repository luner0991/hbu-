
//裁剪 限制字数
var cut = function(str,len){
	if(str.length>len){
		str = str.substring(0,len)+"..."
	}
	return str
}
//获取栏目id
var channelid = $.cookie("channelid").substring(1)

//查找数据
$.ajax({
	url:"HbuServlet",
	type:"get",
	data:{
		channelid,
	},
	success:function(value)
	{
		//console.log(value)
		var arr = value.data
		// 塞到hbu_list.html
		$(".hbu_list ul").empty()
		for(var i=0;i<arr.length;i++){
			$(".hbu_list ul").append("<li>"+
                "<a href='#"+arr[i].id+"' class='toDetail'>"+
                    "<div class='left'>"+
                        "<h3>"+cut(arr[i].title,30)+"</h3>"+
                        "<p>"+cut(arr[i].desc,100)+"</p>"+
                    "</div>"+
                    "<div class='right'>"+
                        "<span>"+arr[i].createtime.substring(0,10)+"</span>"+
                    "</div>"+
               " </a>"+
           " </li>")
		}
		
	}
})

//查找栏目
$.ajax({
	url:"SeachChannelById",
	data:{
		channelid,
	},
	success:function(value)
	{
		$(".hbu_list h2").text(value.data[0].channelname) //更新栏目名称到页面
	}
})

//跳转到列表页
$(".tolist").click(function(){
	//存cookie,携带href属性值
	$.cookie("channelid",$(this).attr("href"))
	//页面跳转
	location.href="hbu_list.html"
})

//跳转到详情页hub_detail
$("body").on("click",".toDetail",function(){
	//存cookie,携带href属性值
	$.cookie("contentid",$(this).attr("href"))
	//页面跳转
	location.href="hbu_detail.html"
})
