// 初始化编辑器
var ue = UE.getEditor('container');
//alert(1)
// 给返回按键绑事件
$(".back").click(function(){
	location.href="content.html"
	
})


//查找栏目，将之前content.js的复制过来就好

var loadChannel = function(){
	 $.ajax({
		 url:"SearchChannel",
		 type:"get",
		 async:false ,//同步
		 success:function(value){
			// console.log(value)
			 var arr = value.data
			 $(".channelid").empty()
			 for(var i=0;i<arr.length;i++){
				 //在容器中追加新的channelid
				 $(".channelid").append('<option value="'+arr[i].id+'">'+arr[i].channelname+'</option>')
			 }
				
		 }
	 })
}
//进入页面加载栏目
loadChannel()


//回显
var id = $.cookie("id")

$.ajax({
		url:"SearchContentById",
		type:"get", 
		data:{
			id
		},
		success:function(value){
			var obj = value.data[0]
			//将后端返回的数据存到输入框中
			$(".title").val(obj.title) // 将对象里面的标题赋值到标题的输入框
			$(".author").val(obj.author)
			$(".desc").val(obj.desc)
			$(".createtime").val(obj.createtime)
			$(".channelid").val(obj.channelid)
			/*$(".content").val(obj.content)*/
			ue.ready(function() {
				//设置编辑器的内容
				ue.setContent(obj.content);
			});
			// 隐藏域设置值
			$(".imgurl").val(obj.imgurl)
			//展示小的缩略图到页面
			$(".show").html("<img src = 'upload/"+obj.imgurl+"' style='width:150px;height:100px;object-fit:cover'>")

		}	
		
	})


//修改
$(".update").click(function(){
	//获取输入框内容 和添加一样
	var channelid = $(".channelid").val() //下拉框
	var title = $(".title").val().trim() //输入标题
	var author = $(".author").val().trim()
	var createtime = $(".createtime").val()
	var desc = $(".desc").val().trim()
	var  content = ue.getContent()
	var  imgurl = $(".imgurl").val()
	$.ajax({
		url:"UpdateContent",
		type:"post", 
		data:{
			channelid,
			title,
			author,
			createtime,
			desc,
			imgurl,
			content,
			id // 多传参一个从cookie中获得的id
		},
		success:function(value){
			alert(value)
			location.href="content.html"
		}
		
	})
})

//图片上传:要等图片选择完之后再进行，所以不应该绑定click事件，应该绑定---change值改变事件
$(".file").on("change",function(){
	//将表单数据序列化
	var img = new FormData($(".imgbox")[0])
	//console.log(data)
	//有数据
	if(img.get("file").name){
		//上传到数据库
		$.ajax({
			url:"UploadServlet",
			type:"post", 
			data:img,
			contentType:false, // 默认是文本信息，现在是图片
			processData:false,// 默认以对象形式上传的数据会被转换为字符串，这里是图片不用转换为字符串
			success:function(value){
			//展示小的缩略图到页面
			$(".show").html("<img src = 'upload/"+value.imgurl+"' style='width:150px;height:100px;object-fit:cover'>")
			//给隐藏域赋值
			$(".imgurl").val( value.imgurl)
			}
			
		})
	}else{
		alert("请选择图片")
	}
	
})


