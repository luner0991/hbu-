//裁剪 限制字数
var cut = function(str,len){
	if(str.length>len){
		str = str.substring(0,len)+"..."
	}
	return str
}
//通知公告
$.ajax({
	url:"HbuServlet",
	type:"get",
	data:{
		channelid:1,
		limit:4
	},
	success:function(value)
	{
		//console.log(value)
		var arr = value.data
		// 塞到前端
		$(".middle ul").empty()
		for(var i=0;i<arr.length;i++){
			$(".middle ul").append("<li>"+
                    "<a href='#"+arr[i].id+"' class='toDetail'>"+
                        "<div class='left'>"+
                        "  <h3>"+arr[i].createtime.substring(8,10)+"</h3>"+
                       "  <p>"+arr[i].createtime.substring(0,7)+"</p>"+
                      " </div>"+
                     " <div class='right'>"+
                    " <h3>"+cut(arr[i].title,20)+"</h3>"+
                   " <p>"+cut(arr[i].desc,60)+"</p>"+
                  " </div>"+
                 " </a>"+
                "</li>")
		}
	}
})

//视频河大
$.ajax({
	url:"HbuServlet",
	type:"get",
	data:{
		channelid:2,
		limit:5
	},
	success:function(value)
	{
		//console.log(value)
		var arr = value.data
		// 塞到前端
		$(".right ul").empty()
		for(var i=0;i<arr.length;i++){
			$(".right ul").append("<li><a href='#"+arr[i].id+"' class='toDetail'>"+cut(arr[i].title,8)+"</a></li>")
		}
		
	}
})

//军训专题
$.ajax({
	url:"HbuServlet",
	type:"get",
	data:{
		channelid:3,
		limit:4
	},
	success:function(value)
	{
		//console.log(value)
		var arr = value.data
		// 塞到前端
		$(".jx ul").empty()
		for(var i=0;i<arr.length;i++){
			$(".jx ul").append("<li>"+
                    "<a href='#"+arr[i].id+"' class='toDetail'>"+
                        "<span>"+arr[i].createtime.substring(0,10)+"</span>"+
                        "<img src='upload/"+arr[i].imgurl+"' alt=''>"+
                        "<h3>"+cut(arr[i].title,8)+"</h3>"+
                        "<p>"+cut(arr[i].desc,60)+"</p>"+
                   " </a>"+
                "</li>")
		}
		
	}
})



//跳转到列表页
$(".tolist").click(function(){
	//存cookie,携带href属性值
	$.cookie("channelid",$(this).attr("href"))
	//页面跳转
	location.href="hbu_list.html"
})



//跳转到详情页hub_detail
$("body").on("click",".toDetail",function(){
	//存cookie,携带href属性值
	$.cookie("contentid",$(this).attr("href"))
	//页面跳转
	location.href="hbu_detail.html"
})



