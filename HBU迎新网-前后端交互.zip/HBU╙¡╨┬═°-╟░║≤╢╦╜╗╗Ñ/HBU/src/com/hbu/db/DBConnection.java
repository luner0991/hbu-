package com.hbu.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

	String driver = "com.mysql.jdbc.Driver";  //5...
	//String driver = "com.mysql.cj.jdbc.Driver";//8...
	String url = "jdbc:mysql://127.0.0.1:3306/hbu?useUnicode=true&characterEncoding=utf-8&serverTimezone=UTC&useSSL=true";
	String user = "root";
	String password = "2020";//
	public Connection conn;

	public DBConnection() {

		try {
			Class.forName(driver);
			conn = (Connection) DriverManager.getConnection(url, user, password);//

			// if(!conn.isClosed())
			// System.out.println("Succeeded connecting to the Database!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void close() {
		try {
			this.conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
