package com.hbu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hbu.db.MysqlUtil;

/**
 * Servlet implementation class SearchContentById
 */
@WebServlet("/SearchContentById")
public class SearchContentById extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchContentById() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//接受参数
		String id = request.getParameter("id");
		//拼接sql
		String sql= "select * from content where id = " + id;
		//存储要查出的字段
		String[] colums = {"id","title","desc","createtime","author","channelid","content","imgurl"} ;
		String res = MysqlUtil.getJsonBySql(sql, colums);//返回给前端
		response.setContentType("text/json;charset=utf-8");
		//数据返回		
		response.getWriter().write(res);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
