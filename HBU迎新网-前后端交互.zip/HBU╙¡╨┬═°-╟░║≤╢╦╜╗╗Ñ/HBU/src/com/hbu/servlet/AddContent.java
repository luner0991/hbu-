package com.hbu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hbu.db.MysqlUtil;

import sun.security.krb5.internal.crypto.crc32;

/**
 * Servlet implementation class AddContent
 */
@WebServlet("/AddContent")
public class AddContent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddContent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//接受参数
		String channelid = request.getParameter("channelid");
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String createtime = request.getParameter("createtime");
		String desc = request.getParameter("desc");
		String content = request.getParameter("content");
		String imgurl = request.getParameter("imgurl");
		//拼接sql + 变量替换
		content = content.replaceAll("\"", "\'");
		String sql = "insert into content(title,`desc`,createtime,author,imgurl,content,channelid) values(\""+title+"\",\""+desc+"\",\""+createtime+"\",\""+author+"\",\""+imgurl+"\",\""+content+"\","+channelid+")";
		int num = MysqlUtil.add(sql);//返回数据库中受影响的行数
		String res ="添加失败";
		if(num>0){
		res="添加成功";
		}
		
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.getWriter().write(res);
	 }

}
