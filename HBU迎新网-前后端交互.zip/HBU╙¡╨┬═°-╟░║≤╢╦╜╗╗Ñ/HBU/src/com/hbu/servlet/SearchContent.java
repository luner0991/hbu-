package com.hbu.servlet;

import java.io.IOException;
import java.nio.channels.Channel;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hbu.db.MysqlUtil;

/**
 * Servlet implementation class SearchContent
 */
@WebServlet("/SearchContent")
public class SearchContent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchContent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String channelid = request.getParameter("channelid");
		String title = request.getParameter("title");
		String author = request.getParameter("author");
		String page = request.getParameter("page");
		String pageSize = request.getParameter("pageSize");
		
		String sql = "select content.*,channelname from content,channel where content.channelid = channel.id";
		// 查找的选项不为空且不是空字符串
		if(channelid!=null && !channelid.equals("") ) {
			sql+=" and channelid = " + channelid;
		}
		if(title!=null && !title.equals("")) {
			sql+=" and title like \"%"+title+"%\"";
		}
		if(author!=null && !author.equals("")) {
			sql+=" and  author = \"" +author+"%\"";
		}
		
		sql+=" order by  createtime desc limit "+(Integer.parseInt(page)-1)*Integer.parseInt(pageSize)+","+pageSize;
		System.out.println(sql);
		
		String[] colums = {"id","title","desc","createtime","author","channelid","channelname","content","imgurl"} ;
		String res = MysqlUtil.getJsonBySql(sql, colums);//返回给前端
		response.setContentType("text/json;charset=utf-8");
		//数据返回		
		response.getWriter().write(res);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
