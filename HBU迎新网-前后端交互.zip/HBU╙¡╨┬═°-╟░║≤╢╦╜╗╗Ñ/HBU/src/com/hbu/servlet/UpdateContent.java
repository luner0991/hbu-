package com.hbu.servlet;

import java.io.IOException;
import java.nio.channels.Channel;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hbu.db.MysqlUtil;

/**
 * Servlet implementation class UpdateContent
 */
@WebServlet("/UpdateContent")
public class UpdateContent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateContent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//接受参数
				String channelid = request.getParameter("channelid");
				String title = request.getParameter("title");
				String author = request.getParameter("author");
				String createtime = request.getParameter("createtime");
				String desc = request.getParameter("desc");
				String content = request.getParameter("content");
				String id = request.getParameter("id");
				String imgurl = request.getParameter("imgurl");
				content = content.replaceAll("\"", "\'");
				//拼接sql + 变量替换
				String sql = "update content set title=\""+title+"\",`desc`=\""+desc+"\",createtime=\""+createtime+"\",author=\""+author+"\",imgurl=\""+imgurl+"\",content=\""+content+"\",channelid= "+channelid+" where id = "+id;
				int num = MysqlUtil.update(sql);//返回数据库中受影响的行数
				String res ="修改失败";
				if(num>0){
				res="修改成功";} 	
				
				request.setCharacterEncoding("utf-8");
				response.setCharacterEncoding("utf-8");
				response.getWriter().write(res);
	}

}
