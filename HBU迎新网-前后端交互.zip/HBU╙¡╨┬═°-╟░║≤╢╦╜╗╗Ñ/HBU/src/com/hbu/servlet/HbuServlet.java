package com.hbu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hbu.db.MysqlUtil;

/**
 * Servlet implementation class HbuServlet
 */
@WebServlet("/HbuServlet")
public class HbuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HbuServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String channelid = request.getParameter("channelid");
		String limit = request.getParameter("limit");
		
		String sql ="select * from content where channelid ="+channelid+" order by  createtime desc ";
		if(limit!=null&&!limit.equals(""))
		{
			sql+="limit 0,"+limit;
		}
		//System.out.println(sql);
		String[] colums = {"id","title","desc","createtime","author","channelid","content","imgurl"} ;
		
		String res = MysqlUtil.getJsonBySql(sql, colums);//返回给前端
		response.setContentType("text/json;charset=utf-8");
		//数据返回		
		response.getWriter().write(res);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
