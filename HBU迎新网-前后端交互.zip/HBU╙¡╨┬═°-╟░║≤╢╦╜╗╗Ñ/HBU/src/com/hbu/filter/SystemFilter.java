package com.hbu.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class SystemFilter
 */
@WebFilter("/*")
public class SystemFilter implements Filter {

    /**
     * Default constructor. 
     */
    public SystemFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		//System.out.println("过滤器");
		
		//想知道请求的资源路径是什么调用：记得强制类型转换
		String URI =((HttpServletRequest)request).getRequestURI();
		// System.out.println(URI);
		//区分资源是否被放行(是否需要登录)
		if(URI.contains("login")||URI.contains("jquery")||URI.contains("LoginServlet")||
		URI.contains("images")||URI.contains("hbu")||URI.contains("HbuServlet")||
		URI.contains("upload")||URI.contains("ById"))
		{
			//放行,不用进行登录
			chain.doFilter(request, response);
		}
		else {
			//如果是登录进来的就放行(在LoginServlet添加一个标识，使用session)
			HttpSession session=((HttpServletRequest)request).getSession();
			if(session.getAttribute("account")!=null) //session不是空 说明登录成功
			{
				chain.doFilter(request, response);
			}
			else { // 不放行,跳转到登录页(重定向)
				((HttpServletResponse)response).sendRedirect("login.html");
				
			}
		}
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
