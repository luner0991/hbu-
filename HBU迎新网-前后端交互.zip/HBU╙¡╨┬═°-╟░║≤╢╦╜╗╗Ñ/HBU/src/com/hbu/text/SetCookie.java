package com.hbu.text;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SetCookie
 */
@WebServlet("/SetCookie")
public class SetCookie extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SetCookie() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 服务器创建cookie对象
		Cookie cookie = new Cookie("account", "admin");
		// 设置cookie有效期 --登录信息第一次被保存后可以存多久
		//>0 cookie有效期
		// =0 删除cookie
		// <0 长会话cookie  如果用户关闭浏览器（完全关闭所有窗口），这个 Cookie 会被自动删除；如果浏览器一直开着，Cookie 会一直有效。
		cookie.setMaxAge(60 * 60 * 24 * 7); // 设置 Cookie 的有效期为 7 天
		//将cookie响应给客户端
		response.addCookie(cookie);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
